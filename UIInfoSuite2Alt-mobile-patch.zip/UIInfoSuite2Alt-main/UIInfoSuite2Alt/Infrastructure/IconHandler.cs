﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI.Utilities;
using StardewValley;
using StardewValley.Menus;
using UIInfoSuite2Alt.UIElements;

namespace UIInfoSuite2Alt.Infrastructure;

public sealed class IconHandler
{
  public static readonly string[] IconKeys =
  [
    "Luck",
    "Weather",
    "Birthday",
    "Festival",
    "QueenOfSauce",
    "ToolUpgrade",
    "RobinBuilding",
    "SeasonalBerry",
    "TravelingMerchant",
    "Bookseller",
    "CustomIcons",
  ];

  private const int IconGap = 48;
  private const int MobileIconGap = 44;

  /// <summary>How many icons per row (horizontal) or column (vertical) before wrapping.</summary>
  public int IconsPerRow { get; set; } = 10;

  private readonly PerScreen<List<QueuedIcon>> _queuedIcons = new(() => []);
  private readonly PerScreen<List<QueuedIcon>> _sortedCache = new(() => []);
  private readonly PerScreen<int> _lastSortedCount = new(() => -1);

  private IconHandler() { }

  public static IconHandler Handler { get; } = new();

  public bool IsQuestLogPermanent { get; set; } = false;

  /// <summary>When true, a quest count number is drawn below the journal icon, requiring more vertical clearance.</summary>
  public bool ShowQuestCount { get; set; } = true;

  /// <summary>The configured icon order, keyed by icon key. Lower = more right.</summary>
  public Dictionary<string, int> IconOrder { get; set; } = [];

  /// <summary>Extra vertical offset (pixels) to avoid overlapping icons from other mods.</summary>
  public int ExtraYOffset { get; set; }

  /// <summary>When true, icons stack vertically downward instead of horizontally to the left.</summary>
  public bool UseVerticalLayout { get; set; }

  /// <summary>Enqueue an icon to draw this frame, sorted by configured order.</summary>
  public void EnqueueIcon(
    string iconKey,
    Action<SpriteBatch, Point> draw,
    Action<SpriteBatch>? drawHover = null
  )
  {
    int order = IconOrder.TryGetValue(iconKey, out int o) ? o : 99;
    _queuedIcons.Value.Add(
      new QueuedIcon
      {
        Draw = draw,
        DrawHover = drawHover,
        SortOrder = order,
        RegistrationOrder = _queuedIcons.Value.Count,
      }
    );
  }

  /// <summary>When true, use mobile-friendly layout: vertical stacking, smaller gap, safe-area-aware position.</summary>
  public bool UseMobileLayout { get; set; } = false;

  /// <summary>Extra Y offset applied on top of MobileLayout calculation (for fine-tuning).</summary>
  public int MobileYOffset { get; set; } = 0;

  /// <summary>Sort, position, draw all queued icons + hover text. Call once per frame.</summary>
  public void DrawQueuedIcons(SpriteBatch batch)
  {
    List<QueuedIcon> icons = _queuedIcons.Value;
    if (icons.Count == 0)
    {
      return;
    }

    // Skip when HUD is hidden (cutscenes, events)
    if (!UIElementUtils.IsRenderingNormally())
    {
      icons.Clear();
      return;
    }

    // Stable sort: config order, then registration order (cached to avoid per-frame allocation)
    List<QueuedIcon> sorted = _sortedCache.Value;
    if (_lastSortedCount.Value != icons.Count)
    {
      sorted.Clear();
      sorted.AddRange(icons.OrderBy(i => i.SortOrder).ThenBy(i => i.RegistrationOrder));
      _lastSortedCount.Value = icons.Count;
    }

    int gap;
    int yPos;
    int xBase;

    if (UseMobileLayout)
    {
      // Mobile: anchor to TitleSafeArea so icons stay inside screen bounds on all Android devices.
      // Use vertical layout by default (stacks downward along right edge).
      gap = MobileIconGap;
      var safeArea = Utility.getSafeArea();
      xBase = safeArea.Right - 52;
      // Start below the toolbar buttons (top-right HUD buttons are ~200px tall on mobile).
      yPos = safeArea.Top + 200 + MobileYOffset;

      if (IsQuestLogPermanent || Game1.player.hasVisibleQuests)
      {
        yPos += ShowQuestCount ? 50 : 20;
      }

      // Force vertical layout in mobile mode so icons don't run off the right edge.
      for (int i = 0; i < sorted.Count; i++)
      {
        Point pos = new Point(xBase, yPos + gap * i);
        sorted[i].Draw(batch, pos);
      }
    }
    else
    {
      // Original PC layout — unchanged.
      gap = IconGap;
      yPos = (Game1.options.zoomButtons ? 290 : 260) + ExtraYOffset;
      xBase = Tools.GetWidthInPlayArea() - 70;

      if (IsQuestLogPermanent || Game1.player.hasVisibleQuests)
      {
        if (UseVerticalLayout)
        {
          xBase -= 16;
          yPos += ShowQuestCount ? 50 : 20;
        }
        else
        {
          xBase -= 67;
        }
      }
      else if (UseVerticalLayout)
      {
        yPos -= 30;
      }

      for (int i = 0; i < sorted.Count; i++)
      {
        int col = i % IconsPerRow;
        int row = i / IconsPerRow;
        Point pos = UseVerticalLayout
          ? new Point(xBase - gap * row, yPos + gap * col)
          : new Point(xBase - gap * col, yPos + gap * row);
        sorted[i].Draw(batch, pos);
      }
    }

    // Draw hover text on top
    foreach (QueuedIcon icon in sorted)
    {
      icon.DrawHover?.Invoke(batch);
    }

    icons.Clear();
    _lastSortedCount.Value = -1;
  }

  public void Reset(object? sender, EventArgs e)
  {
    _queuedIcons.Value.Clear();
    _lastSortedCount.Value = -1;
  }

  private class QueuedIcon
  {
    public Action<SpriteBatch, Point> Draw { get; set; } = null!;
    public Action<SpriteBatch>? DrawHover { get; set; }
    public int SortOrder { get; set; }
    public int RegistrationOrder { get; set; }
  }
}
